# Docs Inventory

This inventory classifies every file under `docs/**` as of the docs taxonomy cleanup. It is an index, not a move record: historical files remain in place unless a future cleanup can move them without breaking checks or links.

## Policy

- Versioned durable facts belong in `docs/releases/v<version>/`.
- `docs/current/` should stay a small active pointer/status area plus stable operational files that checks or users read directly.
- Historical version-specific files in `docs/current/` are retained for compatibility and should be summarized or linked from version capsules before any move.
- Operational runbooks, templates, fixtures, and HQ orchestration docs stay non-versioned unless a release needs a frozen copy.
- Evidence reviews and phase docs are durable history, not active current status.
- Deleting evidence/status history is avoided; use append-only correction or pointer updates first.

## Classification Counts

- archived historical: 3
- current active pointer/status: 42
- current compatibility doc: 21
- current index: 1
- current or historical decision/status: 16
- current status JSON: 1
- evidence review archive: 47
- historical version-specific current doc: 27
- legacy current evidence review: 2
- operational stable: 41
- phase archive: 46
- version-specific release note: 58
- versioned durable: 26

Total indexed files: 331

## File Inventory

| File | Classification | Version | Disposition |
| --- | --- | --- | --- |
| `docs/MEASURED-CLAIMS.md` | operational stable | - | Stable non-versioned public claim-boundary document. |
| `docs/QUICK-DEMO.md` | operational stable | - | Stable non-versioned public setup and gate walkthrough. |
| `docs/README.md` | operational stable | - | Stable non-versioned guide or index. |
| `docs/START-HERE.md` | operational stable | - | Stable non-versioned public first-run reading map. |
| `docs/archive/README.md` | archived historical | - | Historical/superseded record; leave in place and link from indexes when relevant. |
| `docs/archive/docs-taxonomy-archive-plan.md` | archived historical | - | Historical/superseded record; leave in place and link from indexes when relevant. |
| `docs/archive/project-progress-board-2026-06-19-pre-taxonomy.md` | archived historical | - | Historical/superseded record; leave in place and link from indexes when relevant. |
| `docs/current/README.md` | current active pointer/status | - | Current active pointer, checklist, status, or release-operation index. |
| `docs/current/agents-managed-block-contract.md` | current active pointer/status | - | P1 STEP 2 doctor observation plus P1 STEP 3 bounded managed-V1/project-local attach writer; doctor remains inspection-only, with no default, configuration/evidence-schema, measured-negative, version, or release-state change. |
| `docs/current/acceptance-results/README.md` | operational stable | - | Operational fixture/template/runbook; stays non-versioned unless a release freezes a copy. |
| `docs/current/acceptance-results/TEMPLATE.md` | operational stable | - | Operational fixture/template/runbook; stays non-versioned unless a release freezes a copy. |
| `docs/current/acceptance-results/results/2026-07-02-local-current-acceptance-ab.md` | operational stable | - | Operational fixture/template/runbook; stays non-versioned unless a release freezes a copy. |
| `docs/current/acceptance-test-checklist.md` | current active pointer/status | - | Current active pointer, checklist, status, or release-operation index. |
| `docs/current/advanced-surface-index.md` | current active pointer/status | - | Repository-only index for dormant source references and preview/advanced surfaces; not an npm support contract. |
| `docs/current/branch-retention-audit.md` | current active pointer/status | - | Repository-only append-only remote branch/PR retention ledger; no ref deletion authorization. |
| `docs/current/ast-enforcement-rfc.md` | current or historical decision/status | - | Decision/status document; active only if named by docs/current/README.md, otherwise historical reference. |
| `docs/current/backend-clean-code-uniformity-rubric.md` | current compatibility doc | - | Compatibility/current-era doc retained in place; migrate by summary and pointer before moving. |
| `docs/current/backend-product-code-style-direction.md` | current or historical decision/status | - | Decision/status document; active only if named by docs/current/README.md, otherwise historical reference. |
| `docs/current/canonical-docs-index.md` | current active pointer/status | - | Current active pointer, checklist, status, or release-operation index. |
| `docs/current/ci-evidence-reverification-acceptance-record.md` | current active pointer/status | - | Item 19 exact-main opt-in reverify and explicit CI-mode acceptance with package evidence and claim boundaries. |
| `docs/current/ci-evidence-reverification-design.md` | current active pointer/status | - | Item 19 design lineage for the accepted reverification contract; it is not itself the current contract. |
| `docs/current/ci-finish-contract.md` | current active pointer/status | - | Exact CI finish exit/stream and closure JSON artifact contract; documents the absence of `finish --json`. |
| `docs/current/clean-opencode-ph-bearshell-smoke.md` | current compatibility doc | - | Compatibility/current-era doc retained in place; migrate by summary and pointer before moving. |
| `docs/current/desktop-test-artifacts-index.md` | current compatibility doc | - | Compatibility/current-era doc retained in place; migrate by summary and pointer before moving. |
| `docs/current/diff-rules-classification.md` | current active pointer/status | - | T6 classification table for all `references/diff-rules` files; docs-only scope fixture for future T8/T7 decisions. |
| `docs/current/diff-rules-distribution-retirement-acceptance-record.md` | current active pointer/status | - | Item 12 exact-main package/init diff-rules retirement, legacy advisory, and claim boundary record. |
| `docs/current/docs-inventory.md` | current index | - | Inventory for all docs files; active pointer/index file. |
| `docs/current/entry-steering-status.md` | current active pointer/status | - | Default-off OpenCode advisory for the first user message of the latest selected session, source-only corpus measurement, bounded decision status, and no default-on or efficacy claim. |
| `docs/current/evaluation-fixtures/ambiguous-idea-first.md` | operational stable | - | Operational fixture/template/runbook; stays non-versioned unless a release freezes a copy. |
| `docs/current/evaluation-fixtures/backend-api-no-stack.md` | operational stable | - | Operational fixture/template/runbook; stays non-versioned unless a release freezes a copy. |
| `docs/current/evaluation-fixtures/multi-step-backend-small.md` | operational stable | - | Operational fixture/template/runbook; stays non-versioned unless a release freezes a copy. |
| `docs/current/evaluation-fixtures/multi-step-backend.md` | operational stable | - | Operational fixture/template/runbook; stays non-versioned unless a release freezes a copy. |
| `docs/current/evaluation-methodology.md` | operational stable | - | Stable non-versioned guide or index. |
| `docs/current/external-review-adoption-status.md` | current active pointer/status | - | Current active pointer, checklist, status, or release-operation index. |
| `docs/current/evidence-reviews/v0.3.8-alpha.0-clean-workflow-smoke.md` | legacy current evidence review | v0.3.8-alpha.0 | Compatibility location for older evidence review; keep linked rather than moving blindly. |
| `docs/current/evidence-reviews/v0.3.8-alpha.1-clean-tarball-workflow-smoke.md` | legacy current evidence review | v0.3.8-alpha.1 | Compatibility location for older evidence review; keep linked rather than moving blindly. |
| `docs/current/hq-orchestration/README.md` | operational stable | - | Operational fixture/template/runbook; stays non-versioned unless a release freezes a copy. |
| `docs/current/hq-orchestration/protocol.md` | operational stable | - | Operational fixture/template/runbook; stays non-versioned unless a release freezes a copy. |
| `docs/current/hq-orchestration/templates/common-dispatch-header.md` | operational stable | - | Operational fixture/template/runbook; stays non-versioned unless a release freezes a copy. |
| `docs/current/hq-orchestration/templates/dispatch-cli-workflow.md` | operational stable | - | Operational fixture/template/runbook; stays non-versioned unless a release freezes a copy. |
| `docs/current/hq-orchestration/templates/dispatch-docs-release.md` | operational stable | - | Operational fixture/template/runbook; stays non-versioned unless a release freezes a copy. |
| `docs/current/hq-orchestration/templates/dispatch-qa-coverage.md` | operational stable | - | Operational fixture/template/runbook; stays non-versioned unless a release freezes a copy. |
| `docs/current/hq-orchestration/templates/dispatch-research-reference.md` | operational stable | - | Operational fixture/template/runbook; stays non-versioned unless a release freezes a copy. |
| `docs/current/hq-orchestration/templates/dispatch-runtime-injection.md` | operational stable | - | Operational fixture/template/runbook; stays non-versioned unless a release freezes a copy. |
| `docs/current/hq-orchestration/templates/dispatch-skills-prompting.md` | operational stable | - | Operational fixture/template/runbook; stays non-versioned unless a release freezes a copy. |
| `docs/current/hq-orchestration/templates/result-report-format.md` | operational stable | - | Operational fixture/template/runbook; stays non-versioned unless a release freezes a copy. |
| `docs/current/hq-orchestration/thread-index.md` | operational stable | - | Operational fixture/template/runbook; stays non-versioned unless a release freezes a copy. |
| `docs/current/harness-default-audit.md` | current active pointer/status | - | P1 STEP 1 config default/path audit and dead-flag report; no default or runtime behavior change. |
| `docs/current/injection-value-status.json` | current active pointer/status | - | Current active pointer, checklist, status, or release-operation index. |
| `docs/current/injection-value-stopping-rule.md` | current compatibility doc | - | Compatibility/current-era doc retained in place; migrate by summary and pointer before moving. |
| `docs/current/java-backend-actual-quality-shape-review.md` | current compatibility doc | - | Compatibility/current-era doc retained in place; migrate by summary and pointer before moving. |
| `docs/current/java-backend-bootstrap-injection-design.md` | current or historical decision/status | - | Decision/status document; active only if named by docs/current/README.md, otherwise historical reference. |
| `docs/current/java-backend-bootstrap-open-code-demo.md` | current compatibility doc | - | Compatibility/current-era doc retained in place; migrate by summary and pointer before moving. |
| `docs/current/java-backend-mvp-install-guide.md` | operational stable | - | Stable non-versioned guide or index. |
| `docs/current/java-backend-mvp-packaging-readiness.md` | current compatibility doc | - | Compatibility/current-era doc retained in place; migrate by summary and pointer before moving. |
| `docs/current/java-ironlist-gate-matrix.md` | current active pointer/status | - | Item 11 source/fixture/convention-state matrix; docs-only inventory, not an enforcement decision. |
| `docs/current/java-precision-warnings-acceptance-record.md` | current active pointer/status | - | Item 21 exact-main three-rule warn-only acceptance record; not full Iron List enforcement. |
| `docs/current/loop-engineering.md` | current compatibility doc | - | Compatibility/current-era doc retained in place; migrate by summary and pointer before moving. |
| `docs/current/measurement-scorecard.md` | current active pointer/status | - | Current active pointer, checklist, status, or release-operation index. |
| `docs/current/multi-agent-relay-design.md` | current or historical decision/status | - | Decision/status document; active only if named by docs/current/README.md, otherwise historical reference. |
| `docs/current/multiagent-relay-trial-status.md` | current active pointer/status | - | Current active pointer, checklist, status, or release-operation index. |
| `docs/current/mvp-goal.md` | current compatibility doc | - | Compatibility/current-era doc retained in place; migrate by summary and pointer before moving. |
| `docs/current/mvp-scope-consistency-check.md` | current compatibility doc | - | Compatibility/current-era doc retained in place; migrate by summary and pointer before moving. |
| `docs/current/mvp-scope-status.json` | current status JSON | - | Machine-readable status; keep path stable for checks and tools. |
| `docs/current/next-rail-prompt-drafts.md` | current compatibility doc | - | Compatibility/current-era doc retained in place; migrate by summary and pointer before moving. |
| `docs/current/npm-beta-publish-preparation.md` | current compatibility doc | - | Compatibility/current-era doc retained in place; migrate by summary and pointer before moving. |
| `docs/current/omo-steal-measurement-report.md` | current or historical decision/status | - | Decision/status document; active only if named by docs/current/README.md, otherwise historical reference. |
| `docs/current/persona-harness-detailed-usage.md` | operational stable | - | Stable non-versioned guide or index. |
| `docs/current/persona-harness-state-and-version.md` | current compatibility doc | - | Compatibility/current-era doc retained in place; migrate by summary and pointer before moving. |
| `docs/current/persona-workflow-roles-v0.3.md` | current compatibility doc | - | Compatibility/current-era doc retained in place; migrate by summary and pointer before moving. |
| `docs/current/p0-finish-next-action-acceptance-record.md` | current active pointer/status | - | P0-2 exact-main finish follow-up, report-transition, package evidence, and claim boundary record. |
| `docs/current/p0-go-acceptance-record.md` | current active pointer/status | - | P0-1 exact-main acceptance, provenance, package evidence, and claim boundary record. |
| `docs/current/p0-public-discovery-acceptance-record.md` | current active pointer/status | - | P0-3 exact-main public discovery, writer safety, package evidence, and claim boundary record. |
| `docs/current/ph-bearshell-mvp.md` | current compatibility doc | - | Compatibility/current-era doc retained in place; migrate by summary and pointer before moving. |
| `docs/current/ph-core-adapter-boundary-design.md` | current active pointer/status | - | Item 25 design-only PH-core/language-pack/adapter ownership and dependency boundary. |
| `docs/current/p3-integrity-roadmap.md` | current active pointer/status | - | Accepted P3-first integrity roadmap, release hold, assurance model, and P2 hold; docs-only pending implementation. |
| `docs/current/p3-2-closure-authority-acceptance-record.md` | current active pointer/status | - | Candidate finish boundary: unsigned project-local evidence is diagnostic-only and no trusted authority path exists yet. |
| `docs/current/p3-3-verification-receipt-acceptance-record.md` | current active pointer/status | - | Strict receipt/attempt parser and read-only lifecycle diagnostics; no receipt issuance or finish-authority acceptance. |
| `docs/current/p3-8-ci-release-integrity-acceptance-record.md` | current active pointer/status | - | PR/main CI and canonical-main/registry/release idempotency checks plus repository-admin readback; staged-publish least privilege and release approval remain separate gates. |
| `docs/current/p3-9-rc3-integrity-governance-decision.md` | current active pointer/status | - | Exact-main source/package/governance decision: constrained P2 source-only resumption GO; Stable/GA/latest/publish remain NO-GO. |
| `docs/current/stable-containment-execution-evidence.md` | current active pointer/status | - | Issue #60 durable pre-execution record for exact `0.6.0` deprecation; action not yet executed and no latest/next movement. |
| `docs/current/korean-cli-help-scope-authorization.md` | current active pointer/status | - | Sole user-authorized #19 product-scope exception for Korean CLI help locale selection; all other P2 product work and release boundaries remain held. |
| `docs/current/p3-4-fresh-fixed-command-verifier-acceptance-record.md` | current active pointer/status | - | Fresh POSIX Java/Spring/Gradle execution, receipt/attempt issuance, and nonzero testcase enforcement; P3-2 remains blocking. |
| `docs/current/p3-10-external-finish-attestation-verifier-acceptance-record.md` | current active pointer/status | - | Product-owned Sigstore verification, fixed protected-main policy, replay consumption, finish/closure parity, and Node 20 package contract; QA/External remain required. |
| `docs/current/p3-5-semantic-tdd-acceptance-record.md` | current active pointer/status | - | Fresh red-to-green JUnit identity/lineage assessment; local structure remains untrusted and P3-2 remains blocking. |
| `docs/current/phase-artifact-retention-policy.md` | current or historical decision/status | - | Decision/status document; active only if named by docs/current/README.md, otherwise historical reference. |
| `docs/current/phase2-scope-settlement.md` | current compatibility doc | - | Compatibility/current-era doc retained in place; migrate by summary and pointer before moving. |
| `docs/current/productization-path-decision.md` | current or historical decision/status | - | Decision/status document; active only if named by docs/current/README.md, otherwise historical reference. |
| `docs/current/programming-shared-skill-actual-usage-review.md` | current compatibility doc | - | Compatibility/current-era doc retained in place; migrate by summary and pointer before moving. |
| `docs/current/quick-demo-acceptance-record.md` | current active pointer/status | - | Item 24 exact-main public three-beat QUICK-DEMO acceptance record. |
| `docs/current/rail-compliance-evidence-design.md` | current or historical decision/status | - | Decision/status document; active only if named by docs/current/README.md, otherwise historical reference. |
| `docs/current/rail-entry-measurement-status.md` | current active pointer/status | - | Current active pointer, checklist, status, or release-operation index. |
| `docs/current/rail-entry-prompt-regression-gate.md` | current active pointer/status | - | Current active pointer, checklist, status, or release-operation index. |
| `docs/current/ralph-loop-measurement-status.md` | current active pointer/status | - | Current active pointer, checklist, status, or release-operation index. |
| `docs/current/role-scoped-rule-delivery.md` | current active pointer/status | - | T7 role/stage scoped static rule delivery status and boundary record. |
| `docs/current/role-rules-dogfooding-readiness.md` | current active pointer/status | - | T10 ROLE-RULES dogfooding readiness checklist, violation-log template, and next queue. |
| `docs/current/release/README.md` | current active pointer/status | - | Current active pointer, checklist, status, or release-operation index. |
| `docs/current/release/staged-package-artifact-attestation-producer.md` | operational stable | - | Controlled producer-only bootstrap for future exact npm tarball attestation; no shipped verifier, release action, or positive staged-package result. |
| `docs/current/release/staged-package-verification.md` | operational stable | - | Read-only staging-first prerelease verification contract: exact selected `staging` or later-approved `next` facts, local-install checks, and an exact-artifact provenance requirement before any verified result. |
| `docs/current/release/rc-release-readiness-decision.md` | current active pointer/status | - | Exact current-main release decision: next-RC planning may begin, while publication, Stable/GA, and npm latest remain held. |
| `docs/current/release/github-actions-release-automation.md` | operational stable | - | Operational fixture/template/runbook; stays non-versioned unless a release freezes a copy. |
| `docs/current/release/next-version-blocked.md` | operational stable | - | Operational fixture/template/runbook; stays non-versioned unless a release freezes a copy. |
| `docs/current/release/next-version-readiness.md` | operational stable | - | Operational fixture/template/runbook; stays non-versioned unless a release freezes a copy. |
| `docs/current/release/npm-trusted-publishing-runbook.md` | operational stable | - | Operational fixture/template/runbook; stays non-versioned unless a release freezes a copy. |
| `docs/current/release/release-checklist.md` | operational stable | - | Operational fixture/template/runbook; stays non-versioned unless a release freezes a copy. |
| `docs/current/release/release-notes-template.md` | operational stable | - | Operational fixture/template/runbook; stays non-versioned unless a release freezes a copy. |
| `docs/current/release/v0.3.0-alpha.3-candidate.md` | version-specific release note | v0.3.0-alpha.3 | Workflow-compatible release-note source for v0.3.0-alpha.3; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.3.0-alpha.3-demo-packaging-decision.md` | version-specific release note | v0.3.0-alpha.3 | Workflow-compatible release-note source for v0.3.0-alpha.3; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.3.0-alpha.3-release-notes.md` | version-specific release note | v0.3.0-alpha.3 | Workflow-compatible release-note source for v0.3.0-alpha.3; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.3.1-alpha.0-release-notes.md` | version-specific release note | v0.3.1-alpha.0 | Workflow-compatible release-note source for v0.3.1-alpha.0; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.3.2-alpha.0-release-notes.md` | version-specific release note | v0.3.2-alpha.0 | Workflow-compatible release-note source for v0.3.2-alpha.0; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.3.2-alpha.1-release-notes.md` | version-specific release note | v0.3.2-alpha.1 | Workflow-compatible release-note source for v0.3.2-alpha.1; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.3.2-alpha.2-release-notes.md` | version-specific release note | v0.3.2-alpha.2 | Workflow-compatible release-note source for v0.3.2-alpha.2; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.3.2-alpha.3-clean-short-request-review.md` | version-specific release note | v0.3.2-alpha.3 | Workflow-compatible release-note source for v0.3.2-alpha.3; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.3.2-alpha.3-on-off-ab-review.md` | version-specific release note | v0.3.2-alpha.3 | Workflow-compatible release-note source for v0.3.2-alpha.3; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.3.2-alpha.3-release-notes.md` | version-specific release note | v0.3.2-alpha.3 | Workflow-compatible release-note source for v0.3.2-alpha.3; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.3.3-alpha.0-release-notes.md` | version-specific release note | v0.3.3-alpha.0 | Workflow-compatible release-note source for v0.3.3-alpha.0; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.3.4-alpha.0-release-notes.md` | version-specific release note | v0.3.4-alpha.0 | Workflow-compatible release-note source for v0.3.4-alpha.0; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.3.5-alpha.0-release-notes.md` | version-specific release note | v0.3.5-alpha.0 | Workflow-compatible release-note source for v0.3.5-alpha.0; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.3.6-alpha.0-release-notes.md` | version-specific release note | v0.3.6-alpha.0 | Workflow-compatible release-note source for v0.3.6-alpha.0; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.3.6-alpha.1-release-notes.md` | version-specific release note | v0.3.6-alpha.1 | Workflow-compatible release-note source for v0.3.6-alpha.1; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.3.7-alpha.1-release-notes.md` | version-specific release note | v0.3.7-alpha.1 | Workflow-compatible release-note source for v0.3.7-alpha.1; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.3.8-alpha.0-release-notes.md` | version-specific release note | v0.3.8-alpha.0 | Workflow-compatible release-note source for v0.3.8-alpha.0; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.3.8-alpha.1-release-notes.md` | version-specific release note | v0.3.8-alpha.1 | Workflow-compatible release-note source for v0.3.8-alpha.1; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.3.8-alpha.2-release-notes.md` | version-specific release note | v0.3.8-alpha.2 | Workflow-compatible release-note source for v0.3.8-alpha.2; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.3.8-alpha.3-release-notes.md` | version-specific release note | v0.3.8-alpha.3 | Workflow-compatible release-note source for v0.3.8-alpha.3; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.3.8-alpha.4-release-notes.md` | version-specific release note | v0.3.8-alpha.4 | Workflow-compatible release-note source for v0.3.8-alpha.4; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.3.8-alpha.5-release-notes.md` | version-specific release note | v0.3.8-alpha.5 | Workflow-compatible release-note source for v0.3.8-alpha.5; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.3.9-alpha.0-release-notes.md` | version-specific release note | v0.3.9-alpha.0 | Workflow-compatible release-note source for v0.3.9-alpha.0; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.3.9-alpha.1-release-notes.md` | version-specific release note | v0.3.9-alpha.1 | Workflow-compatible release-note source for v0.3.9-alpha.1; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.3.9-alpha.2-release-notes.md` | version-specific release note | v0.3.9-alpha.2 | Workflow-compatible release-note source for v0.3.9-alpha.2; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.3.9-alpha.3-release-notes.md` | version-specific release note | v0.3.9-alpha.3 | Workflow-compatible release-note source for v0.3.9-alpha.3; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.3.9-alpha.4-release-notes.md` | version-specific release note | v0.3.9-alpha.4 | Workflow-compatible release-note source for v0.3.9-alpha.4; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.3.9-alpha.5-release-notes.md` | version-specific release note | v0.3.9-alpha.5 | Workflow-compatible release-note source for v0.3.9-alpha.5; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.3.9-alpha.6-release-notes.md` | version-specific release note | v0.3.9-alpha.6 | Workflow-compatible release-note source for v0.3.9-alpha.6; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.3.9-alpha.7-release-notes.md` | version-specific release note | v0.3.9-alpha.7 | Workflow-compatible release-note source for v0.3.9-alpha.7; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.3.9-alpha.8-release-notes.md` | version-specific release note | v0.3.9-alpha.8 | Workflow-compatible release-note source for v0.3.9-alpha.8; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.4.0-rc.1-release-notes.md` | version-specific release note | v0.4.0-rc.1 | Workflow-compatible release-note source for v0.4.0-rc.1; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.4.0-rc.10-release-notes.md` | version-specific release note | v0.4.0-rc.10 | Workflow-compatible release-note source for v0.4.0-rc.10; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.4.0-rc.2-release-notes.md` | version-specific release note | v0.4.0-rc.2 | Workflow-compatible release-note source for v0.4.0-rc.2; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.4.0-rc.3-release-notes.md` | version-specific release note | v0.4.0-rc.3 | Workflow-compatible release-note source for v0.4.0-rc.3; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.4.0-rc.4-release-notes.md` | version-specific release note | v0.4.0-rc.4 | Workflow-compatible release-note source for v0.4.0-rc.4; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.4.0-rc.5-release-notes.md` | version-specific release note | v0.4.0-rc.5 | Workflow-compatible release-note source for v0.4.0-rc.5; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.4.0-rc.6-release-notes.md` | version-specific release note | v0.4.0-rc.6 | Workflow-compatible release-note source for v0.4.0-rc.6; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.4.0-rc.7-release-notes.md` | version-specific release note | v0.4.0-rc.7 | Workflow-compatible release-note source for v0.4.0-rc.7; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.4.0-rc.8-release-notes.md` | version-specific release note | v0.4.0-rc.8 | Workflow-compatible release-note source for v0.4.0-rc.8; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.4.0-rc.9-release-notes.md` | version-specific release note | v0.4.0-rc.9 | Workflow-compatible release-note source for v0.4.0-rc.9; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.4.0-release-notes.md` | version-specific release note | v0.4.0 | Workflow-compatible release-note source for v0.4.0; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.4.1-rc.1-release-notes.md` | version-specific release note | v0.4.1-rc.1 | Workflow-compatible release-note source for v0.4.1-rc.1; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.4.1-rc.2-release-notes.md` | version-specific release note | v0.4.1-rc.2 | Workflow-compatible release-note source for v0.4.1-rc.2; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.5.0-rc.1-release-notes.md` | version-specific release note | v0.5.0-rc.1 | Workflow-compatible release-note source for v0.5.0-rc.1; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.5.0-rc.2-release-notes.md` | version-specific release note | v0.5.0-rc.2 | Workflow-compatible release-note source for v0.5.0-rc.2; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.5.0-release-notes.md` | version-specific release note | v0.5.0 | Workflow-compatible release-note source for v0.5.0; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.6.0-rc.1-release-notes.md` | version-specific release note | v0.6.0-rc.1 | Workflow-compatible release-note source for v0.6.0-rc.1; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.6.0-rc.2-release-notes.md` | version-specific release note | v0.6.0-rc.2 | Workflow-compatible release-note source for v0.6.0-rc.2; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.6.0-rc.3-release-notes.md` | version-specific release note | v0.6.0-rc.3 | Workflow-compatible release-note source for v0.6.0-rc.3; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.6.0-rc.4-release-notes.md` | version-specific release note | v0.6.0-rc.4 | Workflow-compatible release-note source for v0.6.0-rc.4; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.6.0-release-notes.md` | version-specific release note | v0.6.0 | Workflow-compatible release-note source for v0.6.0; summarize durable facts in docs/releases/v<version>/ when current. |
| `docs/current/release/v0.7.0-rc.1-release-notes.md` | version-specific release note | v0.7.0-rc.1 | Workflow-compatible published release-note source with npm `next`/tag provenance for v0.7.0-rc.1. |
| `docs/current/release/v0.7.0-rc.2-release-notes.md` | version-specific release note | v0.7.0-rc.2 | Workflow-compatible published release-note source with npm `next`/tag/workflow provenance for v0.7.0-rc.2. |
| `docs/current/release/v0.7.0-rc.3-release-notes.md` | version-specific release note | v0.7.0-rc.3 | Workflow-compatible published release-note source with npm `next`, tag, GitHub prerelease, and workflow provenance. |
| `docs/current/release/v0.7.0-rc.4-release-notes.md` | version-specific release note | v0.7.0-rc.4 | Workflow-compatible staging-first source candidate; it records preparation only, not a published tag, package, registry, or promotion fact. |
| `docs/current/release/v0.7.0-rc.5-release-notes.md` | version-specific release note | v0.7.0-rc.5 | Workflow-compatible staging-first source candidate with a fresh source identity; it records preparation only, not a published tag, package, registry, or promotion fact. |
| `docs/current/release/v0.7.0-rc.6-release-notes.md` | version-specific release note | v0.7.0-rc.6 | Workflow-compatible staging-first source candidate with a fresh source identity; it records preparation only, not a published tag, package, registry, or promotion fact. |
| `docs/current/rule-curation.md` | current compatibility doc | - | Compatibility/current-era doc retained in place; migrate by summary and pointer before moving. |
| `docs/current/rule-policy.md` | current or historical decision/status | - | Decision/status document; active only if named by docs/current/README.md, otherwise historical reference. |
| `docs/current/shared-skill-reference-direction.md` | current or historical decision/status | - | Decision/status document; active only if named by docs/current/README.md, otherwise historical reference. |
| `docs/current/skill-auto-routing-result.md` | current compatibility doc | - | Compatibility/current-era doc retained in place; migrate by summary and pointer before moving. |
| `docs/current/skill-hook-role-agentization-roadmap.md` | current or historical decision/status | - | Decision/status document; active only if named by docs/current/README.md, otherwise historical reference. |
| `docs/current/stop-continuation-hook-design.md` | current or historical decision/status | - | Decision/status document; active only if named by docs/current/README.md, otherwise historical reference. |
| `docs/current/team-project-adoption-guide.md` | operational stable | - | Stable non-versioned guide or index. |
| `docs/current/top-level-intent-router-design.md` | current or historical decision/status | - | Decision/status document; active only if named by docs/current/README.md, otherwise historical reference. |
| `docs/current/v0.2.1-package-metadata-audit.md` | historical version-specific current doc | v0.2.1 | Historical v0.2.1 current-era doc; summarize in a version capsule only when the version becomes active again. |
| `docs/current/v0.2.1-release-readiness.md` | historical version-specific current doc | v0.2.1 | Historical v0.2.1 current-era doc; summarize in a version capsule only when the version becomes active again. |
| `docs/current/v0.2.1-support-contract.md` | historical version-specific current doc | v0.2.1 | Historical v0.2.1 current-era doc; summarize in a version capsule only when the version becomes active again. |
| `docs/current/v0.3.0-alpha-publish-readiness.md` | historical version-specific current doc | v0.3.0 | Historical v0.3.0 current-era doc; summarize in a version capsule only when the version becomes active again. |
| `docs/current/v0.3.0-backend-profile-summary-injection-design.md` | historical version-specific current doc | v0.3.0 | Historical v0.3.0 current-era doc; summarize in a version capsule only when the version becomes active again. |
| `docs/current/v0.3.0-blackbear-plan-artifact.md` | historical version-specific current doc | v0.3.0 | Historical v0.3.0 current-era doc; summarize in a version capsule only when the version becomes active again. |
| `docs/current/v0.3.0-domain-behavior-guidance-review.md` | historical version-specific current doc | v0.3.0 | Historical v0.3.0 current-era doc; summarize in a version capsule only when the version becomes active again. |
| `docs/current/v0.3.0-external-tester-feedback-template.md` | historical version-specific current doc | v0.3.0 | Historical v0.3.0 current-era doc; summarize in a version capsule only when the version becomes active again. |
| `docs/current/v0.3.0-external-tester-guide.md` | historical version-specific current doc | v0.3.0 | Historical v0.3.0 current-era doc; summarize in a version capsule only when the version becomes active again. |
| `docs/current/v0.3.0-gradle-spring-build-guidance.md` | historical version-specific current doc | v0.3.0 | Historical v0.3.0 current-era doc; summarize in a version capsule only when the version becomes active again. |
| `docs/current/v0.3.0-installed-package-evidence-noise-policy.md` | historical version-specific current doc | v0.3.0 | Historical v0.3.0 current-era doc; summarize in a version capsule only when the version becomes active again. |
| `docs/current/v0.3.0-intake-transcript-fixture.md` | historical version-specific current doc | v0.3.0 | Historical v0.3.0 current-era doc; summarize in a version capsule only when the version becomes active again. |
| `docs/current/v0.3.0-interactive-intake-design.md` | historical version-specific current doc | v0.3.0 | Historical v0.3.0 current-era doc; summarize in a version capsule only when the version becomes active again. |
| `docs/current/v0.3.0-philosophy-policy-overlay-design.md` | historical version-specific current doc | v0.3.0 | Historical v0.3.0 current-era doc; summarize in a version capsule only when the version becomes active again. |
| `docs/current/v0.3.0-plan-acceptance.md` | historical version-specific current doc | v0.3.0 | Historical v0.3.0 current-era doc; summarize in a version capsule only when the version becomes active again. |
| `docs/current/v0.3.0-profile-schema-decision.md` | historical version-specific current doc | v0.3.0 | Historical v0.3.0 current-era doc; summarize in a version capsule only when the version becomes active again. |
| `docs/current/v0.3.0-project-intake-philosophy-workflow.md` | historical version-specific current doc | v0.3.0 | Historical v0.3.0 current-era doc; summarize in a version capsule only when the version becomes active again. |
| `docs/current/v0.3.0-step-api-contract-scope-decision.md` | historical version-specific current doc | v0.3.0 | Historical v0.3.0 current-era doc; summarize in a version capsule only when the version becomes active again. |
| `docs/current/v0.3.0-workflow-history.md` | historical version-specific current doc | v0.3.0 | Historical v0.3.0 current-era doc; summarize in a version capsule only when the version becomes active again. |
| `docs/current/v0.3.0-workflow-next-surface-decision.md` | historical version-specific current doc | v0.3.0 | Historical v0.3.0 current-era doc; summarize in a version capsule only when the version becomes active again. |
| `docs/current/v0.3.0-workflow-report-status-lifecycle.md` | historical version-specific current doc | v0.3.0 | Historical v0.3.0 current-era doc; summarize in a version capsule only when the version becomes active again. |
| `docs/current/v0.3.1-external-tester-feedback-template.md` | historical version-specific current doc | v0.3.1 | Historical v0.3.1 current-era doc; summarize in a version capsule only when the version becomes active again. |
| `docs/current/v0.3.1-external-tester-guide.md` | historical version-specific current doc | v0.3.1 | Historical v0.3.1 current-era doc; summarize in a version capsule only when the version becomes active again. |
| `docs/current/v0.3.1-workflow-diagnostics-surface.md` | historical version-specific current doc | v0.3.1 | Historical v0.3.1 current-era doc; summarize in a version capsule only when the version becomes active again. |
| `docs/current/v0.3.3-existing-project-adaptation-mode.md` | historical version-specific current doc | v0.3.3 | Historical v0.3.3 current-era doc; summarize in a version capsule only when the version becomes active again. |
| `docs/current/v0.3.6-requirements-draft-workflow.md` | historical version-specific current doc | v0.3.6 | Historical v0.3.6 current-era doc; summarize in a version capsule only when the version becomes active again. |
| `docs/current/v0.3.6-workflow-ticket-backlog.md` | historical version-specific current doc | v0.3.6 | Historical v0.3.6 current-era doc; summarize in a version capsule only when the version becomes active again. |
| `docs/current/v0.4-evaluation-plan.md` | current compatibility doc | - | Compatibility/current-era doc retained in place; migrate by summary and pointer before moving. |
| `docs/current/v0.4-evaluation-runbook.md` | current or historical decision/status | - | Decision/status document; active only if named by docs/current/README.md, otherwise historical reference. |
| `docs/current/vendored-shared-skills-tarball-policy.md` | current or historical decision/status | - | Decision/status document; active only if named by docs/current/README.md, otherwise historical reference. |
| `docs/current/workflow-closure-state-machine-design.md` | current or historical decision/status | - | Decision/status document; active only if named by docs/current/README.md, otherwise historical reference. |
| `docs/current/workflow-string-gate-parsing-audit.md` | current active pointer/status | - | T4 report-status parsing migration and retained string-gate audit record. |
| `docs/current/workflow-state-concurrency.md` | current active pointer/status | - | T5 ownership and conflict-detection record for workflow state writers. |
| `docs/current/workflow-transition-test-map.md` | current compatibility doc | - | Compatibility/current-era doc retained in place; migrate by summary and pointer before moving. |
| `docs/current/workflow.md` | operational stable | - | Stable non-versioned guide or index. |
| `docs/evidence-reviews/README.md` | evidence review archive | - | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/backend-clean-code-parallel-ab-review.md` | evidence review archive | - | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/backend-clean-code-task-fixture-ab-review.md` | evidence review archive | - | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/backend-clean-code-task-fixture-design.md` | evidence review archive | - | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/coupon-product-code-flow-ab-review.md` | evidence review archive | - | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/generated-demo-quality-synthesis.md` | evidence review archive | - | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/gradle-ab-actual-run-review.md` | evidence review archive | - | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/inventory-product-code-flow-ab-review.md` | evidence review archive | - | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/java-common-routing-ab-review.md` | evidence review archive | - | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/java-domain-root-package-plan-ab-review.md` | evidence review archive | - | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/java-global-package-plan-surface.md` | evidence review archive | - | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/java-package-structure-plan-ab-review.md` | evidence review archive | - | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/java-package-structure-plan-surface.md` | evidence review archive | - | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/java-product-code-flow-ab-regrade.md` | evidence review archive | - | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/java-root-semantics-ab-review.md` | evidence review archive | - | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/response-dto-boundary-ab-review.md` | evidence review archive | - | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/spring-boot-entrypoint-package-shape-review.md` | evidence review archive | - | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/v0.2.1-clean-project-quality-review.md` | evidence review archive | v0.2.1 | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/v0.3.0-alpha2-fresh-install-smoke.md` | evidence review archive | v0.3.0 | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/v0.3.0-alpha2-read-coverage-tui-rerun.md` | evidence review archive | v0.3.0 | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/v0.3.0-alpha2-tui-short-implementation-review.md` | evidence review archive | v0.3.0 | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/v0.3.0-bearshell-guidance-clean-generation-review.md` | evidence review archive | v0.3.0 | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/v0.3.0-blackbear-plan-fill-smoke.md` | evidence review archive | v0.3.0 | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/v0.3.0-bootjar-guidance-fresh-on-review.md` | evidence review archive | v0.3.0 | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/v0.3.0-domain-behavior-clean-generation-review.md` | evidence review archive | v0.3.0 | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/v0.3.0-generated-java-target-role-followup.md` | evidence review archive | v0.3.0 | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/v0.3.0-gradle-spring-buildline-smoke.md` | evidence review archive | v0.3.0 | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/v0.3.0-intake-planned-implementation-smoke.md` | evidence review archive | v0.3.0 | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/v0.3.0-intake-planning-smoke.md` | evidence review archive | v0.3.0 | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/v0.3.0-interactive-accepted-plan-implementation-smoke.md` | evidence review archive | v0.3.0 | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/v0.3.0-interactive-intake-planning-smoke.md` | evidence review archive | v0.3.0 | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/v0.3.0-live-http-qa-opencode-smoke.md` | evidence review archive | v0.3.0 | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/v0.3.0-live-http-qa-template-smoke.md` | evidence review archive | v0.3.0 | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/v0.3.0-plan-acceptance-implementation-smoke.md` | evidence review archive | v0.3.0 | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/v0.3.0-plan-based-implementation-smoke.md` | evidence review archive | v0.3.0 | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/v0.3.0-policy-overlay-accepted-implementation-smoke.md` | evidence review archive | v0.3.0 | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/v0.3.0-policy-overlay-clean-workflow-smoke.md` | evidence review archive | v0.3.0 | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/v0.3.0-profile-summary-injection-smoke.md` | evidence review archive | v0.3.0 | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/v0.3.0-repeat-workflow-evidence-noise-review.md` | evidence review archive | v0.3.0 | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/v0.3.0-step-contract-scoped-clean-workflow-smoke.md` | evidence review archive | v0.3.0 | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/v0.3.0-template-fill-history-smoke.md` | evidence review archive | v0.3.0 | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/v0.3.0-workflow-report-status-lifecycle-smoke.md` | evidence review archive | v0.3.0 | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/v0.3.1-review-report-short-tui-smoke.md` | evidence review archive | v0.3.1 | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/v0.3.1-short-tui-workflow-smoke.md` | evidence review archive | v0.3.1 | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/v0.3.1-workflow-guard-clean-tui-smoke.md` | evidence review archive | v0.3.1 | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/v0.3.1-workflow-noise-classification-smoke.md` | evidence review archive | v0.3.1 | Evidence/review record; durable but not the current status surface. |
| `docs/evidence-reviews/v0.3.1-workflow-runner-clean-tui-smoke.md` | evidence review archive | v0.3.1 | Evidence/review record; durable but not the current status surface. |
| `docs/phases/README.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase-next/README.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase-next/phase-next-controller-sql-observer-design.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase-next/phase-next-guard-ast-linter-observation-design.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase-next/phase-next-java-parser-fixture-contract.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase-next/phase-next-java-parser-metadata-spike.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase-next/phase-next-observation-candidate.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase-next/phase-next-plan.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase-next/phase-next-service-storage-observer-design.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase0/README.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase0/phase-0-report.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase0/phase0-rule-selection-review.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase0/phase0-step2-scope.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/README.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-1-frontmatter-worktree-settlement.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-1-schema-validation-policy-decision.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-1-schema-validation-result.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-2-actual-report-review.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-2-additional-actual-report-review.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-2-controller-rule-improvement.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-2-controller-sql-actual-report-review.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-2-controller-sql-next-decision.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-2-next-decision.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-2-next-observation-decision.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-2-observation-pass-decision.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-2-observer-design.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-2-parser-decision.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-2-plan.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-2-report-review.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-completion-audit.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-next-observation-decision.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-plan.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-rule-loader-design.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-service-storage-actual-report-review.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-service-storage-repeat-report-review.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-test-contract-actual-report-review.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-test-contract-cleanup-decision.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-test-contract-follow-up-decision.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-test-contract-matcher-adjustment-design.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-test-contract-matcher-adjustment-result.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-test-contract-observer-design.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-test-contract-repeat-report-review.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-test-contract-response-time-repeat-review.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-test-contract-third-report-review.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-test-contract-time-list-matcher-decision.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/phases/phase1/phase1-test-contract-time-list-matcher-result.md` | phase archive | - | Phase plan/decision/result record; durable phase history. |
| `docs/project-progress-board.md` | operational stable | - | Stable non-versioned guide or index. |
| `docs/releases/README.md` | versioned durable | - | Canonical versioned release capsule, package/version index, or release-capsule index. |
| `docs/releases/package-index.md` | versioned durable | - | Canonical versioned release capsule, package/version index, or release-capsule index. |
| `docs/releases/v0.6.0-rc.1/README.md` | versioned durable | v0.6.0-rc.1 | Canonical versioned release capsule, package/version index, or release-capsule index. |
| `docs/releases/v0.6.0-rc.1/measurements.md` | versioned durable | v0.6.0-rc.1 | Canonical versioned release capsule, package/version index, or release-capsule index. |
| `docs/releases/v0.6.0-rc.1/release-facts.md` | versioned durable | v0.6.0-rc.1 | Canonical versioned release capsule, package/version index, or release-capsule index. |
| `docs/releases/v0.6.0-rc.2/README.md` | versioned durable | v0.6.0-rc.2 | Canonical versioned release capsule, package/version index, or release-capsule index. |
| `docs/releases/v0.6.0-rc.2/measurements.md` | versioned durable | v0.6.0-rc.2 | Canonical versioned release capsule, package/version index, or release-capsule index. |
| `docs/releases/v0.6.0-rc.2/release-facts.md` | versioned durable | v0.6.0-rc.2 | Canonical versioned release capsule, package/version index, or release-capsule index. |
| `docs/releases/v0.6.0-rc.3/README.md` | versioned durable | v0.6.0-rc.3 | Canonical versioned release capsule, package/version index, or release-capsule index. |
| `docs/releases/v0.6.0-rc.3/measurements.md` | versioned durable | v0.6.0-rc.3 | Canonical versioned release capsule, package/version index, or release-capsule index. |
| `docs/releases/v0.6.0-rc.3/release-facts.md` | versioned durable | v0.6.0-rc.3 | Canonical versioned release capsule, package/version index, or release-capsule index. |
| `docs/releases/v0.6.0-rc.4/README.md` | versioned durable | v0.6.0-rc.4 | Canonical versioned release capsule, package/version index, or release-capsule index. |
| `docs/releases/v0.6.0-rc.4/measurements.md` | versioned durable | v0.6.0-rc.4 | Canonical versioned release capsule, package/version index, or release-capsule index. |
| `docs/releases/v0.6.0-rc.4/release-facts.md` | versioned durable | v0.6.0-rc.4 | Canonical versioned release capsule, package/version index, or release-capsule index. |
| `docs/releases/v0.6.0/README.md` | versioned durable | v0.6.0 | Canonical versioned release capsule, package/version index, or release-capsule index. |
| `docs/releases/v0.6.0/measurements.md` | versioned durable | v0.6.0 | Canonical versioned release capsule, package/version index, or release-capsule index. |
| `docs/releases/v0.6.0/release-facts.md` | versioned durable | v0.6.0 | Canonical versioned release capsule, package/version index, or release-capsule index. |
| `docs/releases/v0.7.0-rc.1/README.md` | versioned durable | v0.7.0-rc.1 | Canonical published npm `next` release-candidate capsule with registry/tag provenance. |
| `docs/releases/v0.7.0-rc.1/measurements.md` | versioned durable | v0.7.0-rc.1 | Scoped accepted measurement and observation pointers for the published release candidate. |
| `docs/releases/v0.7.0-rc.1/release-facts.md` | versioned durable | v0.7.0-rc.1 | Published registry/tag/release facts and claim boundaries for the next-channel candidate. |
| `docs/releases/v0.7.0-rc.2/README.md` | versioned durable | v0.7.0-rc.2 | Canonical published npm `next` release-candidate capsule with registry/tag/workflow provenance. |
| `docs/releases/v0.7.0-rc.2/measurements.md` | versioned durable | v0.7.0-rc.2 | Scoped accepted P1 observations and measurement boundaries carried by the published release candidate. |
| `docs/releases/v0.7.0-rc.2/release-facts.md` | versioned durable | v0.7.0-rc.2 | Published registry/tag/workflow facts and claim boundaries for the next-channel candidate. |
| `docs/releases/v0.7.0-rc.3/README.md` | versioned durable | v0.7.0-rc.3 | Canonical published npm `next` release-candidate capsule with registry/tag/workflow provenance. |
| `docs/releases/v0.7.0-rc.3/measurements.md` | versioned durable | v0.7.0-rc.3 | Scoped package-surface observations and claim boundaries carried by the published release candidate. |
| `docs/releases/v0.7.0-rc.3/release-facts.md` | versioned durable | v0.7.0-rc.3 | Published registry/tag/workflow facts and claim boundaries for the next-channel candidate. |
| `docs/troubleshooting/README.md` | operational stable | - | Stable troubleshooting index. |
| `docs/troubleshooting/check-rail-active.md` | operational stable | - | Stable troubleshooting guide for checking whether the PH rail is active. |
| `docs/troubleshooting/enforce-the-gate.md` | operational stable | - | Stable troubleshooting guide for gate enforcement. |
| `docs/troubleshooting/existing-project-profile.md` | operational stable | - | Stable troubleshooting guide for existing-project profile setup. |
| `docs/troubleshooting/no-tickets.md` | operational stable | - | Stable troubleshooting guide for missing workflow tickets. |
| `docs/troubleshooting/rail-ignored.md` | operational stable | - | Stable troubleshooting guide for ignored rail instructions. |
| `docs/troubleshooting/split-recovery.md` | operational stable | - | Stable troubleshooting guide for split recovery. |
